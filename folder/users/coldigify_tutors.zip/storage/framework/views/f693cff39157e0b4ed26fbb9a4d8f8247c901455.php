
<?php $__env->startSection('content'); ?>
<section style="positon:relative;"  class="container">
	<div class="d-flex p-2 justify-content-center align-items-center">
		<div style="positon:absolute; top:0px;" class="card p-2 shadow-sm">
			<div  class="p-2 d-flex justify-content-start align-items-center">
			<span class="text-indicator" style="font-weight:bold;"><?php echo e($about->category); ?> &#8594;</span>
			<span class="text-indicator" style="font-weight:bold;"><?php echo e($about->course_title); ?></span>
			</div>
			<h2 class="m-2"><?php echo e($about->course_title); ?></h2>
			<p class="p-2" style="font-size:15px; font-weight:bold;"><?php echo e($about->description); ?></p>
			<div  class="p-2 d-flex justify-content-start">
			<small>Created by &#8594;<span><?php if(empty($avatar->avatar)): ?>
				<img class="img-rounded" height="30px" width="30px" src="/profile_avatar/default.jpg"> 
				<?php else: ?>
				<img class="img-rounded" height="30px" width="30px" src="/profile_avatar/<?php echo e($avatar->avatar); ?>"> 
				<?php endif; ?>
				<?php echo e($about->tutors_name); ?></span></small>

			</div>
		<h3 class="p-2">Course Content</h3>
		<ol>
		<?php $__currentLoopData = $allmodules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module_title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li class="p-2"><?php echo e($module_title->module_title); ?></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ol>
		</div>
		<div class="card shadow-lg p-2" style="positon:relative; ">
			<video style="margin-top:0px;" loading="lazy" height="400px" width="100%" height="auto" controls>
  <source src="/content/<?php echo e($about->file1); ?>" type="video/mp4">
  <source src="/content/<?php echo e($about->file1); ?>" type="video/ogg">
  Your browser does not support the video tag.
</video>
<h1 style="font-weight:bold;" class="text-bold">&#8358;<?php echo e($about->price); ?></h1>
<?php if(Auth::guard('web')->check()): ?>
<a style="color:white;" href="<?php echo e(route('checkout',$about->course_title)); ?>" class="btn btn-primary btn-block btn-lg">To Checkout</a>
<?php else: ?>
 <?php
        $parameter=[
            'id' => $about->created_at,
            'owner' => $about->unique_id
        ];
        $parameter=Crypt::encrypt($parameter);
        ?>
<a href="<?php echo e(route('redirect',$parameter)); ?>" class="btn btn-primary btn-block btn-lg">Buy now</a>
<?php endif; ?>
<small style="positon:absolute; font-weight: bold; top:40px; color:black;  left:20px; right:20px;">Preview this course</small>
		</div>
	</div>
</section>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\COLDIGIFY\coldigify_tutors\resources\views/preview.blade.php ENDPATH**/ ?>