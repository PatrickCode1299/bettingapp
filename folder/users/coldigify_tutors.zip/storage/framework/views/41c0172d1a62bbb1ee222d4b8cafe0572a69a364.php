
<?php $__env->startSection('content'); ?>
<section class="container-fluid d-flex justify-content-center">
	<!--<div class="side-nav-control d-mobile-none bg-white card p-5">
	<ul class="list-group">
		<a class="text-left fs-5 list-group-item m-2 nobg">Home</a>
		<a class="text-left fs-5 list-group-item m-2 nobg">Courses</a>
		<a class="text-left fs-5 list-group-item m-2 nobg">Chats</a>
	</ul>
	<img alt="ad-pic" src="../img/coldigifylogo.png" style="width: 150px; height: 150px; positon:fixed; margin-top: 20px; bottom: 0px;">
	</div>-->
	<div  class="card  bg-white p-5">
		<div class="container p-2">
		<h2>New Courses</h2>
		<div class="row">
			<?php if(!empty($new_course)): ?>
			<?php $__currentLoopData = $new_course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newcourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-sm-4  shadow-sm">
				<div class="card p-2 dashboard-card">
					<div class="d-flex align-items-center p-2 justify-content-center shadow-sm">
					<img loading="lazy" alt="profile-pic" src="../storage/preview/<?php echo e($newcourse->preview); ?>" class="course-profile-img">
				</div>
				<small class="fs-5" style="margin-left: 10px;"><?php echo e($newcourse->course_title); ?></small>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php else: ?>
			<h5>Featured course will be here..</h5>
			<?php endif; ?>
		</div>
		<div class="list-group dashboard-list" style="margin-top:20px;">
			<h4>My Courses</h4>
			<span class="fs-6">Course Name</span>
			<?php if(!empty($user_course)): ?>
			<?php $__currentLoopData = $user_course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getcourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			 <?php
        $parameter=[
            'id' => $getcourse->course_name,
            'owner' => $getcourse->instructor_name
        ];
        $parameter=Crypt::encrypt($parameter);
        ?>
			<a href="<?php echo e(route('watch.show',$parameter)); ?>" style="font-weight:bold;" class="p-4 list-group-item"><?php echo e($getcourse->course_name); ?></a>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php else: ?>
			<h5>Start here by purchasing a course</h5>
			<?php endif; ?>
		</div>
		</div>
	</div>
	<div class="card d-mobile-none student-detail-short bg-white p-5">
		<div class="container p-2">
			<div class="card d-flex align-items-center p-2 justify-content-center shadow-sm">
				<img class="img-circle user-profile-img" src="../img/coldigifylogo.png">
				<small class="text-center"><?php echo e(Auth::guard('web')->user()->name); ?></small>
			</div>
		</div>
		<div class="list-group dashboard-list" style="margin-top:20px;">
			<h4>Course Progress</h4>
			<a href="" class="list-group-item">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</a>
			<a href="" class="list-group-item">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</a>
			<a href="" class="list-group-item">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</a>
			<a href="" class="list-group-item">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</a>
			<a href="" class="list-group-item">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</a>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\COLDIGIFY\coldigify_tutors\resources\views/auth/student_dashboard.blade.php ENDPATH**/ ?>