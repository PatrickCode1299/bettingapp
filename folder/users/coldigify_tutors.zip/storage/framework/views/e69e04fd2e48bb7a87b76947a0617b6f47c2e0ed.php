

<?php $__env->startSection('content'); ?>
<div class="container-fluid d-flex">
<div class="card bg-white p-4  all-modules-container">
	<div class="list-group">
		<?php $__currentLoopData = $module; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modules): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="list-group-item p-4" style="margin-top: 10px;">
		<img alt="user-content" src="/storage/preview/<?php echo e($modules->preview); ?>" height="100px" width="100px" class="float-left img-rounded img-thumbnail">
		<span><?php echo e($modules->course_title); ?></span>
		<small style="clear:both;"><?php echo e($modules->module_title); ?></small>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>
<div class="video-container" style="flex:2;">
	    <video  id="my-video" loading="lazy" style="width:100%; height:400px;" controls>
  		<source src="/content/<?php echo e($video_details->file1); ?>" type="video/mp4">
  		Your browser does not support the video tag.
		</video>
		
		<div card="card p-4">
		<?php if(empty($tutor_info->avatar)): ?>
		<img height="40px" style="border-radius:50%;" width="40px" class="m-2 img-circle float-left" src="/profile_avatar/default.jpg">
		<?php else: ?>
		<img height="40px" style="border-radius:50%;" width="40px" class="m-2 img-circle float-left" src="/profile_avatar/<?php echo e($tutor_info->avatar); ?>">
		<?php endif; ?>
		<span style="font-weight:bolder;"><?php echo e($tutor_info->name); ?></span>
		<h2 class="m-2" style="clear:both;"><?php echo e($video_details->course_title); ?></h2>
		<p class="m-2" style="clear:both;" class="fs-6"><?php echo e($video_details->description); ?></p>
		<div class="list-group">
		<?php $__currentLoopData = $module; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modules): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="list-group-item p-4" style="margin-top: 10px;">
		<img alt="user-content" src="/storage/preview/<?php echo e($modules->preview); ?>" height="100px" width="100px" class="float-left img-rounded img-thumbnail">
		<span><?php echo e($modules->course_title); ?></span>
		<small style="clear:both;"><?php echo e($modules->module_title); ?></small>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
		</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\COLDIGIFY\coldigify_tutors\resources\views/auth/view.blade.php ENDPATH**/ ?>