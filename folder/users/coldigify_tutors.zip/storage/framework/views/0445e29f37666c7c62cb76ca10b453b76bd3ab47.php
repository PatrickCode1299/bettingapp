
<?php $__env->startSection('content'); ?>
<section class="container-fluid payment-details-table">
	<?php if(!empty($payment_info)): ?>
	<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">Course Name</th>
      <th scope="col">Student Email</th>
      <th scope="col">Instructor Email</th>
      <th scope="col">Payment Date</th>
      <th scope="col">Payment Amount</th>
      <th scope="col">Invoice</th>
      <th scope="col">Status</th>
    </tr>
  </thead><br/>
  <?php $__currentLoopData = $payment_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tbody>
    <tr>
      <td><?php echo e($payment->course_name); ?></td>
      <td><?php echo e($payment->student_email); ?></td>
      <td><?php echo e($payment->instructor_name); ?></td>
      <td><?php echo e($payment->payment_date); ?></td>
      <td><?php echo e($payment->payment_amount); ?></td>
      <td><?php echo e($payment->invoice_id); ?></td>
      <td><?php echo e($payment->status); ?></td>
      
    </tr>
  </tbody><br/>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php else: ?>
<div class="container card shadow-lg">
<h2>You haven't made any payment yet</h2>
</div>
<?php endif; ?>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\COLDIGIFY\coldigify_tutors\resources\views/payment_details.blade.php ENDPATH**/ ?>