<?php $__env->startSection('content'); ?>
      <section class="site-introduction" style="margin-top:0px;">
        <div class="container-fluid d-flex" style="background-color:EFF3F6;">
        <div class="intro-content m-5">
            <h1 style='font-weight:bold;'>Learn any Skill on the Go.</h1>
            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
                Totam incidunt consectetur veritatis aliquam ab ex ipsum<br /> 
                quisquam corporis doloremque dolore, quis ut expedita provident error 
                libero iste repellendus facere illum.</p>
                <button class='btn btn-md btn-primary'>Explore Courses</button>
        </div>
    <div class='static-user-img m-5'>
      <img  class="img-responsive" style="max-width:80%; max-height:80%;" alt="Student Pic" src="../img/student.jpeg" />
        </div>
        </div>
      </section>
      <hr />
      <section class="site-sponsors-corner">
        <div class="container-fluid">
            <div class='btn-group d-flex justify-content-center'>
                <button class="btn btn-primary">Sponsors 1</button>
                <button class="btn btn-primary">Sponsors 2</button>
                <button class="btn btn-primary">Sponsors 3</button>
                <button class="btn btn-primary">Sponsors 4</button>
                <button class="btn btn-primary">Sponsors 5</button>
            </div>
        </div>
      </section>
      <hr />
      <section class="popular-courses-form">
      <form class="form-inline d-flex justify-content-center align-items-center" method="POST">
                <div class="form-group">
                <input type="text" class="form-control" name="coursename" placeholder="Course Name">
                </div>
                <div class="form-group">
                <input type="text" class="form-control" name="tutor_name" placeholder="Tutor Name">
                </div>
            <!--
                This would display an options lists for the most popular courses
                <div>
                <option class='form-control' name='popular_courses'>

                </option>
            </div>
            -->
        </form>
        </section>
    </body>
    <?php $__env->stopSection(); ?>
</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\COLDIGIFY\coldigify_tutors\resources\views/welcome.blade.php ENDPATH**/ ?>