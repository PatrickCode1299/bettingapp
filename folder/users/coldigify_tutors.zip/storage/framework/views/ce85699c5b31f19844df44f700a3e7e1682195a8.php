
<?php $__env->startSection('content'); ?>
<section class="main-content">
  <div class="instructor-view container">
    <div class="card card-head-tutor shadow-lg">
      <div>
      <h2 class="tutor-heading">Hello, <?php echo e(Auth::guard('admin')->user()->name); ?></h2>
      <p class="welcome-text">
      Welcome back to coldigify, do well to make your courses updated and make a well detailed video thanks.
    </p>
    </div>
    <div>
    <img class="welcome-img" src="../img/welcome.png" width="100" height="200" loading="lazy">
    </div>
    </div>
  </div>
</section>
<section class="main-content">
  <div class="instructor-view container">
    <div class="card card-head-tutor shadow-lg">
     <div class="container mt-5">
    <h2 class="text-center">Upload Your Course Modules</h2>
    <div>
    <form id="multi-file-upload-ajax" method="POST"  action="javascript:void(0)" accept-charset="utf-8" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
        <div class="form-group">
        <label for="Course Title" class="fs-5 text-success bold-text">Select Category<span class="text-danger">(make sure to select the right category)</span></label>
       <select class="form-control" name="category" required>
        <option value="Web Development">Web Development</option>
        <option value="Copywriting">Copywriting</option>
        <option value="Desktop Publishing">Desktop Publishing</option>
        <option value="Data Analytics">Data Analytics</option>
        <option value="Graphics Design">Graphics Design</option>
        <option value="Product Management">Product Management</option>
        <option value="Marketing">Marketing</option>
         <option value="Real Estate">Real Estate</option>
         <option value="UI/UX Design">UI / UX Design</option>
         <option value="Photography">Photography</option>
         <option value="Others">Others</option>
       </select>
      </div>
       <div class="form-group">
        <label class="fs-5 text-success bold-text" for="Course Title">Course Title (e.g Microsoft Excel Advance Masterclass)</label>
        <input id="coursename" placeholder="Course Title e.g Data Analytics Masterclass" type="text" class="form-control" name="course_title" required>
      </div>
      <div class="form-group">
      <label class="fs-5 text-success bold-text" for="Module Title">Module Title</label>
        <input id="modulename" placeholder="e.g Module 1 Introduction" type="text" class="form-control" name="module_title" required>
      </div>
      <div class="form-group">
      <label class="fs-5 text-success bold-text" for="Course Description">Course Description</label>
        <textarea style="resize: none;" id="modulename" placeholder="Write a short description about the course you are creating, this would appear whenever the students wants to buy the course... example:Master Python by building 100 projects in 100 days. Learn data science, automation, build websites, games and apps!" type="text" class="form-control create-description" name="description"></textarea>
      </div>
      <div class="form-group">
        <input id="username" type="hidden" name="tutor_name" value="<?php echo e($users->name); ?>">
        <input id="uniqueid" type="hidden" name="unique_id" value="<?php echo e($users->email); ?>">
      </div>
      <div class="form-group">
        <label for="Course Price">Course Price</label>
        <input id="courseprice" placeholder="Course Price" type="text" class="form-control" value="2500" name="price" disabled="true" required>
      </div>
      <div class="form-group">
        <label class="fs-5 text-success bold-text" for="Course Price">Preview Image (This is what the user see when they want to buy the course only jpeg,jpg, png not greater than 200kb size supported)</label>
        <input id="previewimage"  type="file" class="form-control" name="preview">
      </div>
      <div class="form-group">
      <label class="fs-5 text-success bold-text" for="Modules">Module('You can upload multiple videos here MP4 only')</label>
      <input class="form-control" type="file" name="files[]" id="files" placeholder="Choose files" multiple >
      </div>         <br /> 
    
    <div id="percent"  class="text-danger percent"></div>


<div id="status"></div><br />
      <button type="submit" class="btn btn-primary" id="submit">Submit</button>
      </div>     
      </form> 
     </div>
   </div>
 </section>
<section class="main-content">
  <div class="instructor-view container">
  <div class="card card-head-tutor shadow-lg">
<table class="table table-striped">
  <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <thead>
    <tr>
      <th scope="col">Course Title</th>
      <th scope="col">Module</th>
      <th scope="col">Content</th>
      <th scope="col">Price</th>
    </tr>
  </thead><br/>
  <tbody>
    <tr>
      <td><?php echo e($course->course_title); ?></td>
      <td><?php echo e($course->module_title); ?></td>
      <td>
        <div class="embed-responsive embed-responsive-4by3">
        <video loading="lazy" width="100%" height="auto" controls>
  <source src="../content/<?php echo e($course->file1); ?>" type="video/mp4">
  <source src="../content/<?php echo e($course->file1); ?>" type="video/ogg">
  Your browser does not support the video tag.

</video>
    </div>
    </td>
      <td><?php echo e($course->price); ?></td>
    </tr>
  </tbody><br/>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>
</div>
</section>
 <script type="text/javascript" src="../js/jquery.js"></script>
 <script type="text/javascript">
$(document).ready(function (e) {
$.ajaxSetup({
headers: {
'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
}
});
$('#multi-file-upload-ajax').submit(function(e) {
e.preventDefault();
$("#submit").attr('disabled','true');
var formData = new FormData(this);
let courseName=$('#coursename').val();
let userName=$('#username').val();
let uniqueID=$('#uniqueid').val();
let courseprice=$('#courseprice').val();
let modulename=$('#modulename').val();
let previewimage=$('#previewimage')[0];
var bar = $('.bar');


let TotalFiles = $('#files')[0].files.length; //Total files
let files = $('#files')[0];
for (let i = 0; i < TotalFiles; i++) {
formData.append('files' + i, files.files[i]);
}
formData.append('TotalFiles', TotalFiles);
formData.append('tutors_name', userName);
formData.append('unique_id', uniqueID);
formData.append('course_title', courseName);
formData.append('price', courseprice);
formData.append('module_title',modulename);
formData.append('preview',previewimage);
$.ajax({
xhr:function(){
  var xhr=new window.XMLHttpRequest();
  xhr.upload.addEventListener("progress", function(evt){
    if(evt.lengthComputable){
      var percentComplete = (evt.loaded / evt.total) * 100;
      var percent = $('.percent');
      percent.html(Math.round(percentComplete) + "%");
      percent.css('width',percentComplete);
    }
  }, false);
  return xhr;
},


type:'POST',
url: "<?php echo e(route('course.create')); ?>",
data: formData,
cache:false,
contentType: false,
processData: false,
dataType: 'json',
success: (data) => {
this.reset();
$("#submit").removeAttr('disabled');
alert('Files has been uploaded Successfully');
window.location.href="<?php echo e(route('main_dashboard')); ?>";
},
error: function(data){
alert('Fake File Please Upload an Mp4 File');
console.log(data.responseJSON.errors);
}
});
});
});
</script>
<?php $__env->stopSection(); ?>
<?php if(route('main_dashboard')): ?>
<script type="text/javascript">
  document.title='Main Dashboard';
</script>
<?php endif; ?>


<?php echo $__env->make('layouts.tutor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\COLDIGIFY\coldigify_tutors\resources\views/auth/main_dashboard.blade.php ENDPATH**/ ?>