
<?php $__env->startSection('content'); ?>
<section class="main-content">
  <div class="instructor-view container">
    <div class="card card-head-tutor shadow-sm">
      <div>
      <h2 class="tutor-heading">Hello, <?php echo e(Auth::guard('admin')->user()->name); ?></h2>
      <p class="welcome-text">
      You can always update your profile information on here for necessary changes thanks.
    </p>
    </div>
    <div>
    <img class="welcome-img" src="../img/welcome.png" width="100" height="200" loading="lazy">
    </div>
    </div>
  </div>
</section>
<section class="some-info">
  <div class="card card-short-details shadow-sm">
    <h2>Your Location</h2>
    <p><i class="fa fa-location"></i><?php echo e($users->location); ?></p>
  </div>
  <div class="card card-short-details shadow-sm">
  <h2>Date Joined</h2>
  <?php echo e($users->created_at); ?>

  </div>
</section>


<?php if(empty($users->school)): ?>
<section class="education-info">
  <div class="flex-div-edu-info shadow-lg">
    <h2>Complete your education info</h2>
    <form method="POST" action="<?php echo e(route('edu.info')); ?>" class="form-inline">
      <?php echo csrf_field(); ?>
      <div class="form-group">
        <label for="school attended">University | College</label>
        <input type="hidden" value="<?php echo e($users->email); ?>" name="email">
        <input type="text" class="form-control" placeholder="What school did you attend" name="school" required>
      </div><br />
      <div class="form-group">
        <label for="qualificatiion">Qualification Obtained</label>
        <input type="text" class="form-control" placeholder="e.g B.SC, HND, B.A, M.SC" name="qualification">
      </div><br />
      <button class="btn btn-primary btn-md">Save</button>
    </form>
  </div>
</section>
<?php else: ?>
<br />
<section class="education-info-bg">
  <div class="card  card-edu-info">
     <h2>Educational Background</h2>
    <h4>School Attended</h4>
    <p><b><?php echo e($users->school); ?></b></p>
    <h4>Educational Qualification</h4>
    <p><b><?php echo e($users->qualification); ?></b></p>
  </div>
</section>
<?php endif; ?>
<?php if(empty($users->avatar)): ?>
<section class="education-info">
  <div class="flex-div-edu-info shadow-lg">
    <h2>Update your profile picture</h2>
    <form method="POST" action="<?php echo e(route('upload.pic')); ?>" enctype="multipart/form-data" class="form-inline">
      <?php echo csrf_field(); ?>
      <div class="form-group">
        <label>Upload your profile Picture</label>
          <input type="hidden" name="unique_id" value="<?php echo e($users->email); ?>">
          <input type="hidden" name="tutor_name" value="<?php echo e($users->name); ?>">
          <input type="file" name="file" class="form-control file">
        </div><br />
      <button class="btn btn-primary btn-md">Upload</button>
    </form>
  </div>
</section>
<?php else: ?>
<section class="background-info">
  
</section>
<?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php if(route('admin_dashboard')): ?>
<script type="text/javascript">
  document.title='Profile';
</script>
<?php endif; ?>
<?php echo $__env->make('layouts.tutor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\COLDIGIFY\coldigify_tutors\resources\views/auth/admin_dashboard.blade.php ENDPATH**/ ?>