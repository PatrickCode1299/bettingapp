<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $user=Auth::user()->email;
        $user_redirect1=Auth::user()->redirect1;
        $user_redirect2=Auth::user()->redirect2;
        $datavalue1=$user_redirect1;
        $datavalue2=$user_redirect2;
        $fetchredirectuser=DB::table('courses')->where(['created_at'=>$datavalue1,'unique_id'=>$datavalue2])->first();
        if($fetchredirectuser){
        $indexvalue=$fetchredirectuser->course_title;
        $indexvalue2=$fetchredirectuser->unique_id;
        $valid_payment_course=$fetchredirectuser->course_title;

        $check_if_user_paid=DB::table('payments')->where(['instructor_name'=>$indexvalue2,'course_name'=>$valid_payment_course,'student_email'=>$user])->first();
        if($check_if_user_paid){

            $fetch_user_paid_course=DB::table('payments')->where('student_email',$user)->get();
            foreach($fetch_user_paid_course as $user_paid){
            $instructor_email=$user_paid->instructor_name;
            $course_name=$user_paid->course_name;
           $fetch_from_course=DB::table('courses')->where(['unique_id'=>$instructor_email, 'course_title'=>$course_name])->get();
            }
            /**
            $get_course_user_like=DB::table('studyusers')->where('user_email',$user)->get();
            foreach($get_course_user_like as $know_interest){
                $cat=$know_interest->category;
                $fetch_user_interest=DB::table('courses')->where(['category'=>$cat])->whereRaw('course_title' != '$course_name')->get();
            } **/
            return view('home')->with(['user_course'=>$fetch_from_course,'interest'=>'']);
        }else{
        $get_course_module=DB::table('courses')->where(['course_title'=>$indexvalue,'unique_id'=>$indexvalue2])->get();

        return view('preview')->with(['about'=>$fetchredirectuser, 'allmodules'=>$get_course_module]);
           } 
        }else{
            $check_if_user_paid=DB::table('payments')->where(['student_email'=>$user])->first();
        if($check_if_user_paid){

            $fetch_user_paid_course=DB::table('payments')->where('student_email',$user)->get();
            foreach($fetch_user_paid_course as $user_paid){
            $instructor_email=$user_paid->instructor_name;
            $course_name=$user_paid->course_name;
           $fetch_from_course=DB::table('courses')->where(['unique_id'=>$instructor_email, 'course_title'=>$course_name])->get();
            $get_course_user_like=DB::table('studyusers')->where('user_email',$user)->get();
            foreach($get_course_user_like as $know_interest){
                $cat=$know_interest->category;
                $fetch_user_interest=DB::table('courses')->where(['category'=>$cat])->whereRaw('course_title' != '$course_name')->get();
            }
        }
            return view('home')->with(['user_course'=>$fetch_from_course,'interest'=>$fetch_user_interest]);
        }else{
          return view('home')->with(['user_course'=>'','interest'=>'']);  
        }
    }
    
}
}