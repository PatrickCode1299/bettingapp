<?php

namespace App\Http\Controllers;
use App\Tutor;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;

class AdminDashboardController extends Controller
{
   public function index(){
         if (Auth::guard('admin')->check()) {
            $fetchuser=Auth::guard('admin')->user()->email;
            $getuserinfo=DB::table('tutors')->where('school',null)->first();
            $users=DB::table('tutors')->where('email',$fetchuser)->first();
            return view('auth.admin_dashboard')->with(["users"=>$users]);


        }else{
            return view('auth.admin_login');

       
        }
          
   }
}
