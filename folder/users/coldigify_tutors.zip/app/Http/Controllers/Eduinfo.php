<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
class Eduinfo extends Controller
{
    public function index(Request $request){
    if(is_numeric($request->input('school')) || is_numeric($request->input('qualification'))){
    echo "<script>alert('You entered a numeric value, your edu info cannot contain numeric values');</script>";
    return redirect()->route("admin_dashboard");

    }else{
        $school=$request->input('school');
        $email=$request->input('email');
        $qualification=$request->input('qualification');
        DB::table('tutors')->where('email',$email)->update(array('school'=>$school,'qualification'=>$qualification));
        echo "<script>
        alert('Education Records Updated');
        </script>";
        return redirect()->route("admin_dashboard");
    }
    }
    public function createProfilePic(Request $request){
              $validatedData = $request->validate([
            'tutors_name' => '', 
            'unique_id' => '',
            'file' => 'required',

        'file.*' => 'mimes:jpeg,jpg,png'
        ]);
 
     
             
                    $file = $request->file('file');
                    $filename=time().'_'.$file->getClientOriginalName();
                    $filesize=$file->getSize();
                    DB::table('tutors')->where('email',$request->unique_id)->update(array('avatar'=>$filename));
                    Storage::disk('avatar')->put($filename, file_get_contents($file));
                    return redirect()->route("admin_dashboard");
            
}
}