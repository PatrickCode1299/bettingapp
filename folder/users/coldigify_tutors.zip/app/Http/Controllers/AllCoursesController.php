<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Courses;
use App\Models\Tutor;
use Illuminate\Support\Facades\DB;

class AllCoursesController extends Controller
{
    public function index(){
        $fetchcategory=Courses::all()->unique('category');
        $fetchcourseTutors=Tutor::all()->take(6)->unique('email');
        $fetchcourseGraphics=Courses::all()->where('category','Graphics Design')->take(3)->unique('course_title');
        $fetchcourseWeb=Courses::all()->where('category','Web Development')->take(3)->unique('course_title');
        $fetchcourseCopywrite=Courses::all()->where('category','Copywriting')->take(3)->unique('course_title');
        $fetchcoursePublishing=Courses::all()->where('category','Desktop Publishing')->take(3)->unique('course_title');
        $fetchcourseDataAnalyst=Courses::all()->where('category','Data Analytics')->take(3)->unique('course_title');
        $fetchcourseProduct=Courses::all()->where('category','Product Management')->take(3)->unique('course_title');
        $fetchcourseMarketing=Courses::all()->where('category','Marketing')->take(3)->unique('course_title');
        $fetchcourseRealEstate=Courses::all()->where('category','Real Estate')->take(3)->unique('course_title');
        $fetchcourseUI=Courses::all()->where('category','UI/UX Design')->take(3)->unique('course_title');
        $fetchcoursePhotography=Courses::all()->where('category','Photography')->take(3)->unique('course_title');
        return view('courses')->with(["category"=>$fetchcategory, "graphics" => $fetchcourseGraphics,"web"=>$fetchcourseWeb, "copy"=>$fetchcourseCopywrite,"publishing"=>$fetchcoursePublishing,"data"=>$fetchcourseDataAnalyst,"product"=>$fetchcourseProduct,"marketing"=>$fetchcourseMarketing,"estate"=>$fetchcourseRealEstate,"ui"=>$fetchcourseUI,"photo"=>$fetchcoursePhotography,"tutor"=>$fetchcourseTutors]);
    }
}
