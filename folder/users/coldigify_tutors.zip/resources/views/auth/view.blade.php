@extends('layouts.app')

@section('content')
<div class="container-fluid d-flex">
<div class="card bg-white p-4  all-modules-container">
	<div class="list-group">
		@foreach($module as $modules)
		<div class="list-group-item p-4" style="margin-top: 10px;">
		<img alt="user-content" src="/storage/preview/{{$modules->preview}}" height="100px" width="100px" class="float-left img-rounded img-thumbnail">
		<span>{{$modules->course_title}}</span>
		<small style="clear:both;">{{$modules->module_title}}</small>
		</div>
		@endforeach
	</div>
</div>
<div class="video-container" style="flex:2;">
	    <video  id="my-video" loading="lazy" style="width:100%; height:400px;" controls>
  		<source src="/content/{{$video_details->file1}}" type="video/mp4">
  		Your browser does not support the video tag.
		</video>
		
		<div card="card p-4">
		@if(empty($tutor_info->avatar))
		<img height="40px" style="border-radius:50%;" width="40px" class="m-2 img-circle float-left" src="/profile_avatar/default.jpg">
		@else
		<img height="40px" style="border-radius:50%;" width="40px" class="m-2 img-circle float-left" src="/profile_avatar/{{$tutor_info->avatar}}">
		@endif
		<span style="font-weight:bolder;">{{$tutor_info->name}}</span>
		<h2 class="m-2" style="clear:both;">{{$video_details->course_title}}</h2>
		<p class="m-2" style="clear:both;" class="fs-6">{{$video_details->description}}</p>
		<div class="list-group">
		@foreach($module as $modules)
		<div class="list-group-item p-4" style="margin-top: 10px;">
		<img alt="user-content" src="/storage/preview/{{$modules->preview}}" height="100px" width="100px" class="float-left img-rounded img-thumbnail">
		<span>{{$modules->course_title}}</span>
		<small style="clear:both;">{{$modules->module_title}}</small>
		</div>
		@endforeach
	</div>
		</div>
</div>
</div>
@endsection