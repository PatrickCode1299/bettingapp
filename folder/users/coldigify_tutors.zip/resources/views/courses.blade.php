@extends('layouts.app')
@section('content')
<section class="all-courses container-fluid p-5">
	<div class="container-fluid">
		<h3 class=" text-center " style="font-weight:bolder; color:black;">Courses to get you started</h3>
		<div class="slideshow-container embed-responsive-item">
<div class="embed-responsive takearrow embed-responsive-4by3">
<div class="mySlides ">
 <div class="row">
 	<h5>Graphics Design</h5>
 	@foreach($graphics as $ttl)
 	<?php
        $parameter=[
            'id' => $ttl->created_at,
            'owner' => $ttl->unique_id
        ];
        $parameter=Crypt::encrypt($parameter);
        ?>
 	<div class="col-sm-4">
 		<div class="card shadow-sm preview">
 			<img loading="lazy"   class="img-rounded img-thumbnail" src="../storage/preview/{{$ttl->preview}}">
 			<p class="fs-6" style="font-weight: bold; word-wrap:break-word;">{{$ttl->course_title}}</p>
 			<small style="word-wrap:break-word;">{{$ttl->tutors_name}}</small>
 			<a class="btn btn-md btn-primary" href="{{route('preview.show',$parameter)}}">Enrol</a>
 		</div>
 	</div>
 	@endforeach
 </div>
</div>

<div class="mySlides ">
  <div class="row">
  	<h5>Web Development</h5>
  	@foreach($web as $ttl)
  	<?php
        $parameter=[
            'id' => $ttl->created_at,
            'owner' => $ttl->unique_id
        ];
        $parameter=Crypt::encrypt($parameter);
        ?>
 	<div class="col-sm-4">
 		<div class="card shadow-sm preview">
 			<img loading="lazy"   class="img-rounded img-thumbnail" src="../storage/preview/{{$ttl->preview}}">
 			<p class="fs-6" style="font-weight: bold; word-wrap:break-word;">{{$ttl->course_title}}</p>
 			<small style="word-wrap:break-word;">{{$ttl->tutors_name}}</small>
 			<a class="btn btn-md btn-primary" href="{{route('preview.show',$parameter)}}">Enrol</a>
 		</div>
 	</div>
 	@endforeach
 </div>
</div>

<div class="mySlides">
  <div class="row">
  	<h5>Copywriting</h5>
 @foreach($copy as $ttl)
 <?php
        $parameter=[
            'id' => $ttl->created_at,
            'owner' => $ttl->unique_id
        ];
        $parameter=Crypt::encrypt($parameter);
        ?>
 	<div class="col-sm-4">
 		<div class="card shadow-sm preview">
 			<img loading="lazy"   class="img-rounded img-thumbnail" src="../storage/preview/{{$ttl->preview}}">
 			<p class="fs-6" style="font-weight: bold; word-wrap:break-word;">{{$ttl->course_title}}</p>
 			<small style="word-wrap:break-word;">{{$ttl->tutors_name}}</small>
 			<a class="btn btn-md btn-primary" href="{{route('preview.show',$parameter)}}">Enrol</a>
 		</div>
 	</div>
 	@endforeach
 </div>
</div>

<div class="mySlides">
  <div class="row">
  	<h5>Desktop Publishing</h5>
 @foreach($publishing as $ttl)
 <?php
        $parameter=[
            'id' => $ttl->created_at,
            'owner' => $ttl->unique_id
        ];
        $parameter=Crypt::encrypt($parameter);
        ?>
 	<div class="col-sm-4">
 		<div class="card shadow-sm preview">
 			<img loading="lazy"   class="img-rounded img-thumbnail" src="../storage/preview/{{$ttl->preview}}">
 			<p class="fs-6" style="font-weight: bold; word-wrap:break-word;">{{$ttl->course_title}}</p>
 			<small style="word-wrap:break-word;">{{$ttl->tutors_name}}</small>
 			<a class="btn btn-md btn-primary" href="{{route('preview.show',$parameter)}}">Enrol</a>
 		</div>
 	</div>
 	@endforeach
 </div>
</div>
<div class="mySlides">
  <div class="row">
  	<h5>Data Analytics</h5>
 @foreach($data as $ttl)
 <?php
        $parameter=[
            'id' => $ttl->created_at,
            'owner' => $ttl->unique_id
        ];
        $parameter=Crypt::encrypt($parameter);
        ?>
 	<div class="col-sm-4">
 		<div class="card shadow-sm preview">
 			<img loading="lazy"  class="img-rounded img-thumbnail" src="../storage/preview/{{$ttl->preview}}">
 			<p class="fs-6" style="font-weight: bold; word-wrap:break-word;">{{$ttl->course_title}}</p>
 			<small style="word-wrap:break-word;">{{$ttl->tutors_name}}</small>
 			<a class="btn btn-md btn-primary" href="{{route('preview.show',$parameter)}}">Enrol</a>
 		</div>
 	</div>
 	@endforeach
 </div>
</div>
<div class="mySlides">
  <div class="row">
  	<h5>Product Marketing</h5>
 @foreach($product as $ttl)
 <?php
        $parameter=[
            'id' => $ttl->created_at,
            'owner' => $ttl->unique_id
        ];
        $parameter=Crypt::encrypt($parameter);
        ?>
 	<div class="col-sm-4">
 		<div class="card shadow-sm preview">
 			<img loading="lazy"  class="img-rounded img-thumbnail" src="../storage/preview/{{$ttl->preview}}">
 			<p class="fs-6" style="font-weight: bold; word-wrap:break-word;">{{$ttl->course_title}}</p>
 			<small style="word-wrap:break-word;">{{$ttl->tutors_name}}</small>
 			<a class="btn btn-md btn-primary" href="{{route('preview.show',$parameter)}}">Enrol</a>
 		</div>
 	</div>
 	@endforeach
 </div>
</div>
<div class="mySlides">
  <div class="row">
  	<h5>Marketing</h5>
 @foreach($marketing as $ttl)
 <?php
        $parameter=[
            'id' => $ttl->created_at,
            'owner' => $ttl->unique_id
        ];
        $parameter=Crypt::encrypt($parameter);
        ?>
 	<div class="col-sm-4">
 		<div class="card shadow-sm preview">
 			<img loading="lazy"  class="img-rounded img-thumbnail" src="../storage/preview/{{$ttl->preview}}">
 			<p class="fs-6" style="font-weight: bold; word-wrap:break-word;">{{$ttl->course_title}}</p>
 			<small style="word-wrap:break-word;">{{$ttl->tutors_name}}</small>
 			<a class="btn btn-md btn-primary" href="{{route('preview.show',$parameter)}}">Enrol</a>
 		</div>
 	</div>
 	@endforeach
 </div>
</div>
<div class="mySlides">
  <div class="row">
  	<h5>Real Estate</h5>
 @foreach($estate as $ttl)
 <?php
        $parameter=[
            'id' => $ttl->created_at,
            'owner' => $ttl->unique_id
        ];
        $parameter=Crypt::encrypt($parameter);
        ?>
 	<div class="col-sm-4">
 		<div class="card shadow-sm preview">
 			<img loading="lazy"  class="img-rounded img-thumbnail" src="../storage/preview/{{$ttl->preview}}">
 			<p class="fs-6" style="font-weight: bold; word-wrap:break-word;">{{$ttl->course_title}}</p>
 			<small style="word-wrap:break-word;">{{$ttl->tutors_name}}</small>
 			<a class="btn btn-md btn-primary" href="{{route('preview.show',$parameter)}}">Enrol</a>
 		</div>
 	</div>
 	@endforeach
 </div>
</div>
<div class="mySlides">
  <div class="row">
  	<h5>Photography</h5>
 @foreach($photo as $ttl)
 <?php
        $parameter=[
            'id' => $ttl->created_at,
            'owner' => $ttl->unique_id
        ];
        $parameter=Crypt::encrypt($parameter);
        ?>
 	<div class="col-sm-4">
 		<div class="card shadow-sm preview">
 			<img loading="lazy"   class="img-rounded img-thumbnail" src="../storage/preview/{{$ttl->preview}}">
 			<p class="fs-6" style="font-weight: bold; word-wrap:break-word;">{{$ttl->course_title}}</p>
 			<small style="word-wrap:break-word;">{{$ttl->tutors_name}}</small>
 			<a class="btn btn-md btn-primary" href="{{route('preview.show',$parameter)}}">Enrol</a>
 		</div>
 	</div>
 	@endforeach
 </div>
</div>
<div class="mySlides">
  <div class="row">
  <h5>UI Design</h5>
 @foreach($ui as $ttl)
 <?php
        $parameter=[
            'id' => $ttl->created_at,
            'owner' => $ttl->unique_id
        ];
        $parameter=Crypt::encrypt($parameter);
        ?>
 	<div class="col-sm-4">
 		<div class="card shadow-sm preview">
 			<img loading="lazy"  class="img-rounded img-thumbnail" src="../storage/preview/{{$ttl->preview}}">
 			<p class="fs-6" style="font-weight: bold; word-wrap:break-word;">{{$ttl->course_title}}</p>
 			<small style="word-wrap:break-word;">{{$ttl->tutors_name}}</small>
 			<a class="btn btn-md btn-primary" href="{{route('preview.show',$parameter)}}">Enrol</a>
 		</div>
 	</div>
 	@endforeach
 </div>
</div>
<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
<a class="next" onclick="plusSlides(1)">&#10095;</a>

</div>
<br>
</div>
	</div>
    <div class="container p-5">
       <div style="margin-top:40px;" class="container-fluid">
    <div class="slideshow-container embed-responsive-item">
<div class="embed-responsive takearrow embed-responsive-4by3">
    <h5 style="color:rgb(0, 0, 0); font-weight: bold;">Web Development</h5>
<div class="webSlides">
  <div class="row">
    @foreach($web as $ttl)
    <?php
        $parameter=[
            'id' => $ttl->created_at,
            'owner' => $ttl->unique_id
        ];
        $parameter=Crypt::encrypt($parameter);
        ?>
    <div class="col-sm-4">
        <div class="card shadow-sm preview">
        <img loading="lazy"  class="img-rounded img-thumbnail" src="../storage/preview/{{$ttl->preview}}">
            <p class="fs-6" style="font-weight: bold; word-wrap:break-word;">{{$ttl->course_title}}</p>
            <small style="word-wrap:break-word;">{{$ttl->tutors_name}}</small>
            <a class="btn btn-md btn-primary" href="{{route('preview.show',$parameter)}}">Enrol</a>
        </div>
    </div>
    @endforeach
 </div>
</div>

<a class="prev" onclick="addtoSlides(-1)">&#10094;</a>
<a class="next" onclick="addtoSlides(1)">&#10095;</a>
</div>
</div> 
    </div>
</section>
<section class="instructors container-fluid p-5">
	<div class="instructor">
		<h3 style="font-weight:bolder; color:white;">Our Instructors</h3>
	 <div class="row">
	 	@foreach($tutor as $tutors)
	 	<div class="col-sm-4" style="margin-top:20px;">
	 		<div style="height: 200px;" class="card p-4 shadow-lg">
	 			 @if(empty($tutors->avatar))
        <img src="../profile_avatar/default.jpg"
              height="80" class="float-left img-circle tutor-avatar img-rounded" alt="Avatar" loading="lazy" />
        @else
        <img src="../profile_avatar/{{$tutors->avatar}}"
              height="80" class="float-left img-circle tutor-avatar img-rounded" alt="Avatar" loading="lazy" />
        @endif
        <span style="font-weight:bolder; ">{{$tutors->name}}</span>
        <p>{{$tutors->school}}</p>
        <p>{{$tutors->qualification}}</p>
	 		</div>
	 	</div>
	 	@endforeach
	 </div>
	</div>
</section>
<section  class="explore m-5">
        <div class='container explore-container'>
        <div class="explore-heading">
        <h1 class="text-center bold">Explore Company Courses.</h1>
        <p class="text-center" style="word-wrap:break-word;">Coldigify is a leading e-learning platform in Nigeria with well vast tutors all over differrent locations across Nigeria, offering their courses. To provide a huge impact on the students who enrol for the courses on our platform.</p>
        </div> 
            <div class="row explore explore-card bg-none">
            @foreach($category as $cat)
            <div class='col-sm-4'>
             <div class="card">
            <div class="card-body fs-3 text-center">
            {{$cat->category}}
            </div>
            </div>
            </div>
            @endforeach
            </div>
            <center><button style='margin-top:40px' class="btn btn-md btn-primary">Explore all</button></center>
        </div>
        </section>
<script type="text/javascript" src="../js/slide.js"></script>
<script type="text/javascript">
        var slideIndex = 1;
showSlides(slideIndex);

function addtoSlides(n) {
  displaySlides(slideIndex += n);
}

function currentSlide(n) {
  displaySlides(slideIndex = n);
}

function displaySlides(n) {
  var i;
  var slides = document.getElementsByClassName("webSlides");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  slides[slideIndex-1].style.display = "block";  
  
}
</script>
@endsection